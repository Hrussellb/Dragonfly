"""
# This file is the main server portion of the program that uses both zmq and python
"""
"""
This script is for running the server side stuff for the chat system
this includes the fact that it:
1. listens for messages sent by clients aka the pull socket 
2. takes those messages and broadcasts them to all connected clients or the pub socket 
3. (what i think could be interesting) then automatically deletes the messages after a set time for them to live 
4. finally it will send a system notification when messages expire! 
As for the communication the client push messages -> sever Pull socket 
with server Publishes a messages -> clients Sub scribe to them 
server.py - Dragonfly Chat server (ZeroMQ) with message TTL (auto-delete).
PUB -> tcp://*:5556  (server -> clients)
PULL-> tcp://*:5557  (clients -> server)
"""
import zmq           # ZeroMQ library for distributed messaging
import time          # Used for sleeping between cleanup cycles
import json          # Used to encode/decode the messages in JSON
import threading     # Used for background cleanup tasks
from datetime import datetime, timedelta, timezone # For timestamps and expiration
PUB_ADDR = "tcp://*:5556"
PULL_ADDR = "tcp://*:5557"
TTL_SECONDS = 60  # Message lifespan on the server in secondshello
CLEAN_INTERVAL = 5  # How often the server will clean expired messages

recent_messages = []  # List of tuples: (ts_datetime, payload_dict)
lock = threading.Lock()

def now_dt():
    """Returns current UTC time as a timezone-aware datetime object."""
    return datetime.now(timezone.utc)

def to_iso(dt):
    """Converts the datetime to ISO format with Z."""
    # Ensure dt is timezone-aware and in UTC
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

def cleanup_worker(pub_socket, stop_event):
    """Periodically removes old messages and notifies clients when messages expire."""
    while not stop_event.is_set():
        time.sleep(CLEAN_INTERVAL)
        cutoff = now_dt() - timedelta(seconds=TTL_SECONDS)
        with lock:
            before = len(recent_messages)
            remaining = [(ts, msg) for ts, msg in recent_messages if ts >= cutoff]
            expired_count = before - len(remaining)
            recent_messages[:] = remaining
        if expired_count > 0:
            notice = {
                "type": "system",
                "text": f"{expired_count} message(s) auto-deleted (TTL = {TTL_SECONDS}s)",
                "ts": to_iso(now_dt())
            }
            pub_socket.send_string(json.dumps(notice))
            print(f"[cleanup] removed {expired_count} expired messages")


def main():
    ctx = zmq.Context()
    pub = ctx.socket(zmq.PUB)
    pub.bind(PUB_ADDR)
    pull = ctx.socket(zmq.PULL)
    pull.bind(PULL_ADDR)

    print("The Dragonfly chat server is now running with auto-delete feature")
    print(f" PUB -> {PUB_ADDR}")
    print(f" PULL -> {PULL_ADDR}")
    print(f" TTL -> {TTL_SECONDS} seconds")

    stop_event = threading.Event()
    cleaner = threading.Thread(target=cleanup_worker, args=(pub, stop_event), daemon=True)
    cleaner.start()

    try:
        while True:
            raw = pull.recv_string()
            msg = json.loads(raw)
            ts = now_dt()
            payload = {
                "type": msg.get("type", "chat"),
                "sender": msg.get("sender", "Unknown"),
                "text": msg.get("text", ""),
                "ts": to_iso(ts)
            }
            with lock:
                recent_messages.append((ts, payload))
            pub.send_string(json.dumps(payload))
            print(f"[{payload['ts']}] {payload['sender']}: {payload['text']}")
    except KeyboardInterrupt:
        print("\nServer shutting down...")
    finally:
        stop_event.set()
        cleaner.join(timeout=1.0)
        pub.close(linger=0)
        pull.close(linger=0)
        ctx.term()

if __name__ == "__main__":
    main()

