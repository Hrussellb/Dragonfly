import zmq           # ZeroMQ library for networking
import json          # Encode/decode messages
import threading     # To run listener and display in parallel
import time
import sys
import os
from datetime import datetime, timedelta, timezone
SERVER_HOST = "localhost"      # Default server location
PUB_PORT = 5556                # Must match server PUB port
PULL_PORT = 5557               # Must match server PULL port
TTL_SECONDS = 300               # 5 minutes
RENDER_INTERVAL = 1.0          # Screen update frequency
messages = []                  # List of messages (dicts)
lock = threading.Lock()
stop_event = threading.Event()
def parse_iso_to_dt(s):
    """Convert ISO timestamp back to datetime object."""
    try:
        if s.endswith("Z"):
            s = s[:-1]
        # Try parsing with microseconds
        try:
            dt = datetime.strptime(s, "%Y-%m-%dT%H:%M:%S.%f")
        except ValueError:
            # Try parsing without microseconds
            dt = datetime.strptime(s, "%Y-%m-%dT%H:%M:%S")
        return dt.replace(tzinfo=timezone.utc)
    except Exception as e:
        print(f"Failed to parse timestamp '{s}': {e}")
        return datetime.now(timezone.utc)

def clear_screen():
    """Clears the terminal window for redrawing."""
    os.system('cls' if os.name == 'nt' else 'clear')


def listener_thread(pub_addr):
    """
    Listens for messages broadcast by the server and appends them to the list.
    Runs in a background thread.
    """
    ctx = zmq.Context.instance()
    sub = ctx.socket(zmq.SUB)
    sub.connect(pub_addr)
    sub.setsockopt_string(zmq.SUBSCRIBE, "")  # Subscribe to all messages

    while not stop_event.is_set():
        try:
            raw = sub.recv_string(flags=zmq.NOBLOCK)
            obj = json.loads(raw)
            ts = parse_iso_to_dt(obj.get("ts", ""))
            entry = {
                "ts": ts,
                "type": obj.get("type", "chat"),
                "sender": obj.get("sender", "SYSTEM"),
                "text": obj.get("text", "")
            }
            with lock:
                messages.append(entry)
        except zmq.Again:
            time.sleep(0.1)
    sub.close(linger=0)




def renderer_thread(username):
    """
    Periodically clears and redraws the screen showing active messages.
    Only messages newer than TTL_SECONDS are displayed.
    """
    while not stop_event.is_set():
        cutoff = datetime.utcnow() - timedelta(seconds=TTL_SECONDS)

        with lock:
            #this keeps recent messages only 
            messages[:] = [m for m in messages if m["ts"] >= cutoff]
            visible = list(messages)

        clear_screen()
        print(f"Dragonfly Chat (User: {username}) — TTL = {TTL_SECONDS}s")
        print("-" * 70)
        if not visible:
            print("(no recent messages)")
        else:
            now = datetime.utcnow()
            for m in visible:
                age = (now - m["ts"]).total_seconds()
                remaining = max(0, int(TTL_SECONDS - age))
                ts = m["ts"].strftime("%H:%M:%S")
                if m["type"] == "system":
                    print(f"[{ts}] [SYSTEM] {m['text']}")
                else:
                    print(f"[{ts}] {m['sender']}: {m['text']} (expires in {remaining}s)")
        print("-" * 70)
        print("Type your message below. Use /quit or /exit to leave.")
        time.sleep(RENDER_INTERVAL)

def main():
    # Get username and optional server host from command line args
    username = sys.argv[1] if len(sys.argv) > 1 else input("Enter your name: ").strip() or "anon"
    server_host = sys.argv[2] if len(sys.argv) > 2 else SERVER_HOST

    pub_addr = f"tcp://{server_host}:{PUB_PORT}"
    push_addr = f"tcp://{server_host}:{PULL_PORT}"

    ctx = zmq.Context.instance()
    push = ctx.socket(zmq.PUSH)
    push.connect(push_addr)

    # Start background listener + renderer
    threading.Thread(target=listener_thread, args=(pub_addr,), daemon=True).start()
    threading.Thread(target=renderer_thread, args=(username,), daemon=True).start()

    # Main input loop
    try:
        while True:
            line = input("> ").strip()
            if not line:
                continue
            if line.lower() in ("/quit", "/exit"):
                print("Goodbye!")
                break
            # Add timestamp to outgoing message
            payload = {
                "type": "chat",
                "sender": username,
                "text": line,
                "ts": datetime.now(timezone.utc).isoformat() + "Z"
            }
            push.send_string(json.dumps(payload))
    except (KeyboardInterrupt, EOFError):
        print("\nExiting...")
    finally:
        stop_event.set()
        push.close(linger=0)
        ctx.term()
if __name__ == "__main__":
    main()
