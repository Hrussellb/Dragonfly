echo "venv/
__pycache__/
*.pyc
*.egg-info/
.env" > .gitignore